"""
@author: jtahstu
@contact: root@jtahstu.com
@site: http://www.jtahstu.com
@time: 2017/12/10 00:25
"""
# -*- coding: utf-8 -*-
import random

import requests
from bs4 import BeautifulSoup
import time
from pymongo import MongoClient

headers = {
    'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,image/apng,*/*;q=0.8',
    'Accept-Encoding': 'gzip, deflate, br',
    'Accept-Language': 'zh-CN,zh;q=0.9,zh-TW;q=0.8,en;q=0.7',
    'Connection': 'keep-alive',
    'Cookie': '__c=1513350136; __l=r=&l=%2F; lastCity=101020100; __jsluid=1e3e2beae73bfca4c89fd38e00d8524a; JSESSIONID=""; __g=-; __a=41702256.1513350136..1513350136.2.1.2.2; Hm_lvt_194df3105ad7148dcf2b98a91b5e727a=1513350139; Hm_lpvt_194df3105ad7148dcf2b98a91b5e727a=1513350144',
    'DNT': '1',
    'Host': 'www.zhipin.com',
    'Referer': 'https://www.zhipin.com/',
    'Upgrade-Insecure-Requests': '1',
    'User-Agent': 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_12_1) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/60.0.3202.94 Safari/537.36'
}

# proxies = {
#     'http': 'http://121.232.145.168:9000',
#     'https': 'https://119.122.214.153:9000',
# }

conn = MongoClient('mongodb://127.0.0.1:27017/')
db = conn.iApp


def init():
    items = db.jobs_php.find()
    for item in items:
        if 'detail' in item.keys():
            continue
        detail_url = "https://www.zhipin.com/job_detail/%s.html?ka=search_list_1" % item['pid']
        print(detail_url)
        html = requests.get(detail_url, headers=headers)
        print(html.status_code)
        if html.status_code != 200:
            print('status_code is %d' % html.status_code)
            break
        soup = BeautifulSoup(html.text, "html.parser")
        job = soup.select(".job-sec .text")
        if len(job) < 1:
            sleep()
            continue
        item['detail'] = job[0].text.strip()  # 职位描述
        location = soup.select(".job-sec .job-location")
        item['location'] = location[0].text.strip()  # 工作地点
        item['updated_at'] = time.strftime("%Y-%m-%d %H:%M:%S", time.localtime())  # 爬取时间
        res = save(item)
        print(res)
        sleep()


def sleep():
    time.sleep(int(random.uniform(50, 70)))


def save(item):
    return db.jobs_php.update_one({"_id": item['_id']}, {"$set": item})


if __name__ == "__main__":
    init()
