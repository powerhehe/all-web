# -*- coding: utf-8 -*-
import random
import scrapy
import time
from www_zhipin_com.items import WwwZhipinComItem


class ZhipinSpider(scrapy.Spider):
    # spider的名字定义了Scrapy如何定位(并初始化)
    # spider，所以其必须是唯一的。 不过您可以生成多个相同的spider实例(instance)，这没有任何限制。 name是spider最重要的属性，而且是必须的
    name = 'zhipin'
    allowed_domains = ['www.zhipin.com']
    start_urls = ['http://www.zhipin.com/']
    # 北京、上海、广州、深圳、杭州、天津、西安、苏州、武汉、厦门、长沙、成都
    positionUrls = ['https://www.zhipin.com/c101010100/h_101020100/?query=',
                    'https://www.zhipin.com/c101020100/h_101020100/?query=',
                    'https://www.zhipin.com/c101280100/h_101020100/?query=',
                    'https://www.zhipin.com/c101280600/h_101020100/?query=',
                    'https://www.zhipin.com/c101210100/h_101020100/?query=',
                    'https://www.zhipin.com/c101030100/h_101020100/?query=',
                    'https://www.zhipin.com/c101110100/h_101020100/?query=',
                    'https://www.zhipin.com/c101190400/h_101020100/?query=',
                    'https://www.zhipin.com/c101200100/h_101020100/?query=',
                    'https://www.zhipin.com/c101230200/h_101020100/?query=',
                    'https://www.zhipin.com/c101250100/h_101020100/?query=',
                    'https://www.zhipin.com/c101270100/h_101020100/?query=']
    positions = ['php', 'java', 'python', '前端', 'C++', 'iOS', '安卓']

    curPage = 13  # 当前开始跑的页码
    curPositionUrlIndex = 5  # 当前跑的第几个城市
    curPositionIndex = 2  # 当前跑的第几个岗位

    headers = {
        'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,image/apng,*/*;q=0.8',
        'Accept-Encoding': 'gzip, deflate, br',
        'Accept-Language': 'zh-CN,zh;q=0.9,zh-TW;q=0.8,en;q=0.7',
        'Connection': 'keep-alive',
        'Cookie': '__c=1512975768; __g=-; __jsluid=1f48e9bb513264f042ebc8fd259b3473; toUrl=https%3A%2F%2Fwww.zhipin.com%2Fjob_detail%2F1416202413.html%3Fka%3Dsearch_list_4_blank; lastCity=101020100; JSESSIONID=""; __l=l=%2Fc101020100%2Fh_101020100%2F%3Fquery%3Dphp%26page%3D1%26ka%3Dpage-1&r=; __a=11247336.1512806029.1512806029.1512975768.109.4.39.109; Hm_lvt_194df3105ad7148dcf2b98a91b5e727a=1512806030,1512975768; Hm_lpvt_194df3105ad7148dcf2b98a91b5e727a=1513303794',
        'DNT': '1',
        'Host': 'www.zhipin.com',
        'Referer': 'https://www.zhipin.com/',
        'Upgrade-Insecure-Requests': '1',
        'User-Agent': 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_13_1) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/62.0.3202.94 Safari/537.36'
    }

    def start_requests(self):
        return [self.next_request()]

    def parse(self, response):
        print("request -> " + response.url)
        job_list = response.css('div.job-list > ul > li')
        for job in job_list:
            item = WwwZhipinComItem()
            job_primary = job.css('div.job-primary')
            item['pid'] = job.css(
                'div.info-primary > h3 > a::attr(data-jobid)').extract_first().strip()
            item["positionName"] = job_primary.css(
                'div.info-primary > h3 > a::text').extract_first().strip()
            item["salary"] = job_primary.css(
                'div.info-primary > h3 > a > span::text').extract_first().strip()
            info_primary = job_primary.css(
                'div.info-primary > p::text').extract()
            item['city'] = info_primary[0].strip()
            item['workYear'] = info_primary[1].strip()
            item['education'] = info_primary[2].strip()

            item['companyShortName'] = job_primary.css(
                'div.info-company > div.company-text > h3 > a::text'
            ).extract_first().strip()
            company_infos = job_primary.css(
                'div.info-company > div.company-text > p::text').extract()
            if len(company_infos) == 3:
                item['industryField'] = company_infos[0].strip()
                item['financeStage'] = company_infos[1].strip()
                item['companySize'] = company_infos[2].strip()
            item['positionLables'] = job.css(
                'li > div.job-tags > span::text').extract()
            item['time'] = job.css('span.time::text').extract_first().strip()
            item['updated_at'] = time.strftime("%Y-%m-%d %H:%M:%S", time.localtime())
            yield item

        if self.curPage == 20:
            self.curPage = 1
            self.curPositionUrlIndex += 1  # 下一个城市
            # if self.curPositionUrlIndex > len(self.positionUrls):  # 下一个岗位
            #     self.curPositionIndex += 1
        else:
            self.curPage += 1
        time.sleep(int(random.uniform(50, 70)))
        yield self.next_request()

    def next_request(self):
        return scrapy.http.FormRequest(
            self.positionUrls[self.curPositionUrlIndex] + (
                    "%s&page=%d&ka=page-%d" % (self.positions[self.curPositionIndex], self.curPage, self.curPage)),
            headers=self.headers,
            callback=self.parse
        )
