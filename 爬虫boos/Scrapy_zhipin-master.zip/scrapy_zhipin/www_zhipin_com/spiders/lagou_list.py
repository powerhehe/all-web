"""
@author: jtahstu
@contact: root@jtahstu.com
@site: http://www.jtahstu.com
@time: 2017/12/18 15:44
"""
import json
from pprint import pprint
import requests
import time
import random
from pymongo import MongoClient

headers = {
    'Accept': 'application/json, text/javascript, */*; q=0.01',
    'Accept-Encoding': 'gzip, deflate, br',
    'Accept-Language': 'zh-CN,zh;q=0.9,zh-TW;q=0.8,en;q=0.7',
    'Cache-Control': 'no-cache',
    'Connection': 'keep-alive',
    'Content-Length': '23',
    'Content-Type': 'application/x-www-form-urlencoded; charset=UTF-8',
    'Cookie': 'user_trace_token=20171214222435-8245db41-e0da-11e7-9d45-5254005c3644; LGUID=20171214222435-8245de65-e0da-11e7-9d45-5254005c3644; index_location_city=%E4%B8%8A%E6%B5%B7; _ga=GA1.2.566616671.1513261475; JSESSIONID=ABAAABAACEBACDGEA354AFB727F9DD672DAABD269C1A08F; _gid=GA1.2.1337386859.1513581214; Hm_lvt_4233e74dff0ae5bd0a3d81c6ccf756e6=1513261476,1513581214; LGSID=20171218151334-f5dbe587-e3c2-11e7-9e48-525400f775ce; PRE_UTM=; PRE_HOST=; PRE_SITE=; PRE_LAND=https%3A%2F%2Fwww.lagou.com%2F; TG-TRACK-CODE=index_navigation; SEARCH_ID=170f28639d7c4f49a5339dd187dd9e55; Hm_lpvt_4233e74dff0ae5bd0a3d81c6ccf756e6=1513581333; LGRID=20171218151533-3c79f3d3-e3c3-11e7-9e48-525400f775ce',
    'DNT': '1',
    'Host': 'www.lagou.com',
    'Origin': 'https://www.lagou.com',
    'Pragma': 'no-cache',
    'Referer': 'https://www.lagou.com/jobs/list_PHP?city=%E4%B8%8A%E6%B5%B7&cl=false&fromSearch=true&labelWords=&suginput=',
    'User-Agent': 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_13_2) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/63.0.3239.84 Safari/537.36',
    'X-Anit-Forge-Code': '0',
    'X-Anit-Forge-Token': 'None',
    'X-Requested-With': 'XMLHttpRequest'
}

conn = MongoClient('mongodb://127.0.0.1:27017/')
db = conn.iApp


def getACityAPage(city, page):
    url = 'https://www.lagou.com/jobs/positionAjax.json?px=default&city=%s&needAddtionalResult=false&isSchoolJob=0' % city
    print(url)
    html = requests.post(url, data={
        'first': 'false',
        'pn': page,
        'kd': 'PHP'
    }, headers=headers)
    print(html.status_code)
    if html.status_code != 200:
        print('status_code is %d' % html.status_code)
        quit(0)
    jdict = json.loads(html.text)
    jcontent = jdict["content"]
    jposresult = jcontent["positionResult"]
    jresult = jposresult["result"]
    global totalPageCount
    totalPageCount = jposresult['totalCount'] / 15 + 1
    if totalPageCount > 30:
        totalPageCount = 30
    if page == 1:
        return totalPageCount, jresult
    else:
        return jresult


def init():
    citys = ['北京', '上海', '广州', '深圳', '杭州', '天津', '西安', '苏州', '武汉', '厦门', '长沙', '成都']
    for city in citys:
        page, items = getACityAPage(city, 1)
        save(items)
        for i in range(2, int(page) + 1):
            time.sleep(20)
            items = getACityAPage(city, i)
            save(items)
            print("%s 第 %d 页 ok" % ((city, i)))


def save(items):
    for item in items:
        if db.jobs_lagou_php.find({'positionId': item['positionId']}).count() == 1:
            print('position %d 已存在' % (item['positionId']))
        else:
            res = db.jobs_lagou_php.insert_one(item)
            print(res)


if __name__ == "__main__":
    init()
