"""
@author: jtahstu
@contact: root@jtahstu.com
@site: http://www.jtahstu.com
@time: 2017/12/15 17:30
"""
import datetime
import json

from pymongo import MongoClient
from pprint import pprint
import jieba
import jieba.posseg as psg

db = MongoClient('127.0.0.1', 27017).iApp


def jieba_cut_test():
    jieba.enable_parallel(4)
    jieba.load_userdict("dict.txt")
    items = db.jobs_php.find({}).sort('pid')
    str = "/".join([item['detail'] for item in items if 'detail' in item.keys()])
    seg_list = psg.cut(str)

    stop_words = ['公司', '以上', '以上学历', '至少', '代码', '以及', '实际', '根据', '能力', '经验', '编程', '系统', '专业', '团队', '岗位职责',
                  '技术', '岗位', ]
    seg_list = [(x.word.lower(), x.flag) for x in seg_list if
                len(x.word) >= 2 and x.word not in stop_words]
    # and not x.flag.startswith('v') and not x.flag.startswith(
    #     'm') and not x.flag.startswith('a')
    # and (x.flag.startswith('n') or x.flag.startswith('e'))
    seg_set = set(seg_list)
    seg_arr = []
    for seg in seg_set:
        seg_arr.append((seg_list.count(seg), seg[0], seg[1]))
    seg_arr = sorted(seg_arr, reverse=True)
    seg_arr = [{'count': x, 'word': y, 'type': z} for (x, y, z) in seg_arr]
    # pprint(seg_arr)
    for item in seg_arr:
        db.jobs_php_keywords.insert(item)
    print(json.dumps(seg_arr, ensure_ascii=False))


def get_value():
    items = db.jobs_php_keywords.find()
    data = [{'name': item['word'], 'value': int(item['count'])} for item in items if
            item['type'] == 'eng' and item['count'] > 10]
    pprint(data)
    print('ok')


def get_values():
    items = db.jobs_php_keywords.find({'type': 'eng'})
    print(sum([item['count'] for item in items]))
    # for item in items:
    #     if int(item['count']) > 10 and item['word'] not in ['php', 'mysql']:
    #         for x in range(1, int(item['count']) + 1):
    #             print(item['word'], end=' ')


def init():
    get_values()


if __name__ == "__main__":
    init()
