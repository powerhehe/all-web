"""
@author: jtahstu
@contact: root@jtahstu.com
@site: http://www.jtahstu.com
@time: 2017/12/15 13:12
"""
from pprint import pprint

import datetime
from pymongo import MongoClient

db = MongoClient('mongodb://127.0.0.1:27017/').iApp


def init():
    item_zhipin = db.jobs_zhipin_php.find({})
    item_lagou = db.jobs_lagou_php.find({})
    lables_arr = [item['education'] for item in item_zhipin if 'education' in item.keys() and item['education']]
    for i in item_lagou:
        if 'education' in i.keys() and i['education']:
            lables_arr.append(i['education'])
    lables_set = set(lables_arr)
    out = []
    for lable in lables_set:
        out.append((lables_arr.count(lable), lable))
    out = sorted(out, reverse=True)
    out_arr = [{'value': x, 'name': y} for (x, y) in out[0:30]]
    if len(out_arr) > 30:
        out_arr.append({'value': sum([x for (x, y) in out[30:]]), 'name': 'other'})
    pprint(out_arr)
    print("基于%d条招聘信息 (%s更新)" % (len(lables_arr), str(datetime.date.today())))
    print([item['name'] for item in out_arr])


if __name__ == "__main__":
    init()
