"""
@author: jtahstu
@contact: root@jtahstu.com
@site: http://www.jtahstu.com
@time: 2017/12/15 13:12
"""
from pprint import pprint

import datetime
from pymongo import MongoClient

db = MongoClient('mongodb://127.0.0.1:27017/').iApp


def init():
    # items = db.jobs_zhipin_php.find({})
    items = db.jobs_lagou_php.find({})
    lables = [item['positionLables'] for item in items if len(item['positionLables']) >= 1]
    lables_arr = []
    for lable in lables:
        lables_arr += lable
    lables_set = set(lables_arr)
    out = []
    for lable in lables_set:
        out.append((lables_arr.count(lable), lable))
    out = sorted(out, reverse=True)
    tag_php = out.pop(0)
    out_arr = [{'value': x, 'name': y} for (x, y) in out[0:30]]
    out_arr.append({'value': sum([x for (x, y) in out[30:]]), 'name': 'other'})
    pprint(out_arr)
    print(out[30:80])
    print("基于%d条招聘的%d个标签 (排除%d个php标签,%s更新)" % (len(lables), len(lables_arr), tag_php[0], str(datetime.date.today())))


if __name__ == "__main__":
    init()
