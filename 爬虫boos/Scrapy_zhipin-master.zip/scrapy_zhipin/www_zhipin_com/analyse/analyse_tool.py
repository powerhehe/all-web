"""
@author: jtahstu
@contact: root@jtahstu.com
@site: http://www.jtahstu.com
@time: 2017/12/16 16:34
"""
from pymongo import MongoClient

db = MongoClient('mongodb://127.0.0.1:27017/').iApp


def insert_php_analyse(data):
    return db.jobs_php_analyse.insert_one(dict(data))
