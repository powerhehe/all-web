"""
@author: jtahstu
@contact: root@jtahstu.com
@site: http://www.jtahstu.com
@time: 2017/12/15 13:12
"""
from pprint import pprint
import datetime
import time
from pymongo import MongoClient

db = MongoClient('mongodb://127.0.0.1:27017/').iApp

def getAllData():
    items_zhipin = db.jobs_zhipin_php.find()
    items_lagou = db.jobs_lagou_php.find()
    items = mergerData(items_zhipin, items_lagou)
    data = getData(items)
    data.update({'city': '全国'})
    return data


def getCityData(city):
    items_zhipin = db.jobs_zhipin_php.find({'city': city})
    items_lagou = db.jobs_lagou_php.find({'city': city})
    items = mergerData(items_zhipin, items_lagou)
    data = getData(items)
    data.update({'city': city})
    return data


def mergerData(item_zhipin, item_lagou):
    items = [{'level': i['level'], 'salary': i['salary']} for i in item_zhipin if type(i['salary']) == type({'x': 1})]
    for j in item_lagou:
        if type(j['salary']) == type({'x': 1}):
            items.append({'level': j['level'], 'salary': j['salary']})
    return items


def getData(items):
    data = {}
    # lables_arr = [item['salary'] for item in items if 'salary' in item.keys()]
    level_salary = [(x['level'], x['salary']) for x in items]
    levels = set([x[0] for x in level_salary])
    data['x'] = [level_to_workYear(x) for x in levels]
    low_avg = []
    avg_avg = []
    high_avg = []
    count_arr = []
    for level in levels:
        salarys = sorted([i[1]['avg'] for i in level_salary if i[0] == level])
        if len(salarys) > 5:
            e = int(len(salarys) * 0.9) - 1
        else:
            e = len(salarys) - 1
        salarys_arr = [item[1] for item in level_salary if item[0] == level and item[1]['avg'] <= salarys[e]]
        count = len(salarys_arr)
        count_arr.append(count)
        avg_sum = low_sum = high_sum = 0
        for salary in salarys_arr:
            avg_sum += salary['avg']
            low_sum += salary['low']
            high_sum += salary['high']
        avg_avg.append(round(avg_sum / count, 2))
        low_avg.append(round(low_sum / count, 2))
        high_avg.append(round(high_sum / count, 2))
        # print("%s 平均薪资:%.2f 平均最低薪资%.2f 平均最高薪资%.2f\n" % (level_to_workYear(level), avg_avg, low_avg, high_avg))
    data['low_avg'] = low_avg
    data['avg_avg'] = avg_avg
    data['high_avg'] = high_avg
    data['count'] = count_arr
    data['subtext'] = "基于%d条招聘信息 (%s更新)" % (sum(count_arr), str(datetime.date.today()))
    data['updated_at'] = time.strftime("%Y-%m-%d %H:%M:%S", time.localtime())
    data['type'] = 'salary'
    data['status'] = 1
    # pprint(data)
    return data


def level_to_workYear(level):
    list = {1: '应届生', 2: '1年以内', 3: '1-3年', 4: '3-5年', 5: '5-10年', 6: '10年以上', 10: '经验不限'}
    return list[level]


def init():
    db.jobs_php_analyse.update_many({"type": 'salary'}, {"$set": {'status': 0}})
    citys = db.jobs_zhipin_php.distinct('city')
    for city in citys:
        print(db.jobs_php_analyse.insert_one(dict(getCityData(city))))
        # data = getCityData(city)
        # pprint(data)
    # pprint(getAllData())
    pprint(db.jobs_php_analyse.insert_one(dict(getAllData())))
    print('analyse salary ok')


if __name__ == "__main__":
    init()
