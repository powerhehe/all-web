"""
@author: jtahstu
@contact: root@jtahstu.com
@site: http://www.jtahstu.com
@time: 2017/12/15 13:12
"""
from pprint import pprint

import datetime
from pymongo import MongoClient

db = MongoClient('mongodb://127.0.0.1:27017/').iApp


def init():
    items = db.jobs_zhipin_php.find({})
    lables_arr = [item['industryField'] for item in items if 'industryField' in item.keys()]
    lables = lables_arr
    # items = db.jobs_lagou_php.find({})  # 拉钩
    # lables = [item['industryField'].split(',') for item in items if
    #           'industryField' in item.keys() and item['industryField']]
    # lables_arr = []
    # for lable in lables:
    #     lables_arr += [i.strip() for i in lable]

    lables_set = set(lables_arr)
    out = []
    for lable in lables_set:
        out.append((lables_arr.count(lable), lable))
    out = sorted(out, reverse=True)
    out_arr = [{'value': x, 'name': y} for (x, y) in out if x >= 10]
    other_sum = sum([x for (x, y) in out if x < 10])
    out_arr.append({'value': other_sum, 'name': 'other'})
    pprint(out_arr)
    print("基于%d条招聘信息 (%s更新)" % (len(lables), str(datetime.date.today())))
    print([item['name'] for item in out_arr])


if __name__ == "__main__":
    init()
