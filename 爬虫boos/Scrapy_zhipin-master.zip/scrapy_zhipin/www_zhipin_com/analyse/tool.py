"""
@author: jtahstu
@contact: root@jtahstu.com
@site: http://www.jtahstu.com
@time: 2017/12/14 22:02
"""
from pymongo import MongoClient

db = MongoClient('mongodb://127.0.0.1:27017/').iApp


def init():
    # find_duplicate()
    # print(len([item['pid'] for item in db.jobs_php.find() if 'detail' in item.keys()]))
    print(db.jobs_lagou_php.find_one({'positionId', 3936381}))

def find_duplicate():
    items = db.jobs_java.find().sort('pid')
    pid_arr = [item['pid'] for item in items]
    print(len(pid_arr))
    pid_set = set(pid_arr)
    print(len(pid_set))
    x = []
    for i in pid_set:
        if pid_arr.count(i) > 1:
            x.append(i)
    print(x)

if __name__ == "__main__":
    init()
