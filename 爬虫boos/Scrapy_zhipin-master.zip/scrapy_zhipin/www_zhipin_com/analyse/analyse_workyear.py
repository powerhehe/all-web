"""
@author: jtahstu
@contact: root@jtahstu.com
@site: http://www.jtahstu.com
@time: 2017/12/15 13:12
"""
from pprint import pprint
import datetime
import time
from pymongo import MongoClient

db = MongoClient('mongodb://127.0.0.1:27017/').iApp


def getAllData():
    items_zhipin = db.jobs_zhipin_php.find()
    items_lagou = db.jobs_lagou_php.find()
    items = mergerData(items_zhipin, items_lagou)
    data = getData(items)
    data.update({'city': '全国'})
    return data


def getCityData(city):
    items_zhipin = db.jobs_zhipin_php.find({'city': city})
    items_lagou = db.jobs_lagou_php.find({'city': city})
    items = mergerData(items_zhipin, items_lagou)
    data = getData(items)
    data.update({'city': city})
    return data


def mergerData(item_zhipin, item_lagou):
    items = [{'workYear': i['workYear']} for i in item_zhipin]
    for j in item_lagou:
        items.append({'workYear': j['workYear']})
    return items


def getData(items):
    data = {}
    lables_arr = [item['workYear'] for item in items if 'workYear' in item.keys()]
    lables_set = set(lables_arr)
    out = []
    for lable in lables_set:
        out.append((lables_arr.count(lable), lable))
    out = sorted(out, reverse=True)
    out_arr = [{'value': x, 'name': y} for (x, y) in out[0:30]]
    if len(out_arr) > 30:
        out_arr.append({'value': sum([x for (x, y) in out[30:]]), 'name': 'other'})
    data['data'] = out_arr
    data['subtext'] = "基于%d条招聘信息 (%s更新)" % (len(lables_arr), str(datetime.date.today()))
    data['updated_at'] = time.strftime("%Y-%m-%d %H:%M:%S", time.localtime())
    data['type'] = 'workyear'
    data['status'] = 1
    # pprint(data)
    return data


def init():
    db.jobs_php_analyse.update_many({"type": 'workyear'}, {"$set": {'status': 0}})
    citys = db.jobs_zhipin_php.distinct('city')
    for city in citys:
        data = getCityData(city)
        print(db.jobs_php_analyse.insert_one(dict(data)))
        # pprint(data)
    pprint(db.jobs_php_analyse.insert_one(dict(getAllData())))
    print('analyse workyear ok')


if __name__ == "__main__":
    init()
