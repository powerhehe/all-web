"""
@author: jtahstu
@contact: root@jtahstu.com
@site: http://www.jtahstu.com
@time: 2017/12/12 10:54
"""

# -*- coding: utf-8 -*-

import datetime
import json

from pymongo import MongoClient
from pprint import pprint

# import jieba
# import jieba.posseg as psg

db = MongoClient('127.0.0.1', 27017).iApp


def save(data):
    return db.jobs_php_detail.insert(data)


def find_detail(pid):
    return db.jobs_php_detail.find_one({'pid': pid})


def update(data):
    return db.jobs_zhipin_php.update_one({"_id": data['_id']}, {"$set": data})


def update_lagou(data):
    return db.jobs_lagou_php.update_one({"_id": data['_id']}, {"$set": data})


# 把时间校正过来
def clear_time():
    items = db.jobs_php.find({})
    for item in items:
        if not item['time'].find('布于'):
            continue
        item['time'] = item['time'].replace("发布于", "2017-")
        item['time'] = item['time'].replace("月", "-")
        item['time'] = item['time'].replace("日", "")
        if item['time'].find("昨天") > 0:
            item['time'] = str(datetime.date.today() - datetime.timedelta(days=1))
        elif item['time'].find(":") > 0:
            item['time'] = str(datetime.date.today())
        update(item)
    print('ok')


# 薪水处理成数字
def clear_salary():
    items = db.jobs_lagou_php.find({})
    for item in items:
        if type(item['salary']) == type({}):
            continue
        salary_list = item['salary'].lower().replace("k", "000").split("-")
        if len(salary_list) != 2:
            print(salary_list)
            continue
        try:
            salary_list = [int(x) for x in salary_list]
        except:
            print(salary_list)
            continue
        item['salary'] = {
            'low': salary_list[0],
            'high': salary_list[1],
            'avg': (salary_list[0] + salary_list[1]) / 2
        }
        update(item)
    print('ok')


def work_year_group():
    # items = db.jobs_lagou_php.find({}, {"workYear": 1})
    # items_value = set([x["workYear"] for x in items])
    # print(items_value)
    print(db.jobs_lagou_php.distinct('workYear'))
    # {'1-3年', '5-10年', '3-5年', '1年以内', '经验不限', '应届生'}
    # "应届毕业生",
    # "1-3年",
    # "3-5年",
    # "5-10年",
    # "不限",
    # "1年以下",
    # "10年以上"


# 设置招聘的水平
def set_level():
    items = db.jobs_zhipin_php.find({})
    for item in items:
        if item['workYear'] == '应届生':
            item['level'] = 1
        elif item['workYear'] == '1年以内':
            item['level'] = 2
        elif item['workYear'] == '1-3年':
            item['level'] = 3
        elif item['workYear'] == '3-5年':
            item['level'] = 4
        elif item['workYear'] == '5-10年':
            item['level'] = 5
        elif item['workYear'] == '10年以上':
            item['level'] = 6
        elif item['workYear'] == '经验不限':
            item['level'] = 10
        update(item)
    print('ok')


def update_lagou_workyear():
    items = db.jobs_lagou_php.find({})
    for item in items:
        if item['workYear'] == '应届毕业生':
            item['workYear'] = '应届生'
        elif item['workYear'] == '1年以下':
            item['workYear'] = '1年以内'
        elif item['workYear'] == '不限':
            item['workYear'] = '经验不限'
        update_lagou(item)
    print('ok')


def level_to_workYear(level):
    list = {1: '应届生', 2: '1年以内', 3: '1-3年', 4: '3-5年', 5: '5-10年', 6: '10年以上', 10: '经验不限'}
    return list[level]


# python3 clear_data.py > words.txt
def jieba_cut_test():
    jieba.enable_parallel(4)
    jieba.load_userdict("dict.txt")
    items = db.jobs_php.find({})
    str = "/".join([item['detail'] for item in items if 'detail' in item.keys()])
    seg_list = psg.cut(str)

    stop_words = ['公司', '以上', '以上学历', '至少', '代码', '以及', '实际', '根据', '能力', '经验', '编程', '系统', '专业', '团队', '岗位职责',
                  '技术', '岗位', '开发', '负责']
    seg_list = [(x.word.lower(), x.flag) for x in seg_list if
                len(x.word) >= 2 and x.word not in stop_words and not x.flag.startswith('v')
                and not x.flag.startswith('m') and not x.flag.startswith('a')]
    print(len(seg_list))
    # and not x.flag.startswith('v') and not x.flag.startswith(
    #     'm') and not x.flag.startswith('a')
    # and (x.flag.startswith('n') or x.flag.startswith('e'))

    # seg_set = set(seg_list)
    # seg_arr = []
    # for seg in seg_set:
    #     seg_arr.append((seg_list.count(seg), seg[0], seg[1]))
    # seg_arr = sorted(seg_arr, reverse=True)
    # seg_arr = [{'count': x, 'word': y, 'type': z} for (x, y, z) in seg_arr]

    # pprint(seg_arr)
    # for item in seg_arr:
    #     db.jobs_php_keywords.insert(item)
    # print(json.dumps(seg_arr, ensure_ascii=False))

    # for i in seg_arr[0:301]:
    #     if i['count'] >= 10 and i['word'] not in stop_words:
    #         for x in range(1, i['count'] + 1):
    #             print(i['word'], end=' ')


def init():
    # clear_time()
    # clear_salary()

    # set_level()
    update_lagou_workyear()
    # jieba_cut_test()


if __name__ == "__main__":
    init()
