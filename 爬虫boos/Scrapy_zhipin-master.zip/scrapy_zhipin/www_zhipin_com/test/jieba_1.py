"""
@author: jtahstu
@contact: root@jtahstu.com
@site: http://www.jtahstu.com
@time: 2017/12/12 10:18
"""
import jieba


def init():
    print(list(jieba.cut('我们中出了一个叛徒')))


if __name__ == "__main__":
    init()
