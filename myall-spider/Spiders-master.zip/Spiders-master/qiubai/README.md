# Spider qiubai

This spider crawls qiushibaike.com using scrapy. It extends CrawlSpider but use Spider style. CrawlSpider style such as Rule, LinkExtractor will be used soon.

Data crawled will be saved in MongoDB.

You can give me a star if it helps you. 

Cite it when you use it to write any blog or post.

# Copyright

@ychen