# Spider kongjie
It's a spider using requests and BeautifulSoup to crawl kongjie.com. It is concise enough because of requests and bs4.

It use Redis hash to de-duplicate.

You can give me a star if it helps you. 

Cite it when you use it to write any blog or post.

# Copyright

@ychen