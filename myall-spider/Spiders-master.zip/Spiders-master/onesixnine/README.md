# Spider onesixnine

This spider crawls 169ee.com using scrapy. A spider which can crawl all images in 169ee.com. It use CrawlSpider to crawl the full site. Rule and LinkExtractor are used to extract links to follow. Images will be saved in the disk. 

Image download records crawled will be saved in MongoDB.

You can give me a star if it helps you. 

Cite it when you use it to write any blog or post.

# Copyright

@ychen